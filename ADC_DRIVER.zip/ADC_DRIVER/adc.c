#include "adc.h"

int8_t ADC_Init(ADC_Config_t *config){	
config->Instance=ADC1;	//we have only one adc (ADC1)
RCC->APB2ENR|=(1<<8);//enable rcc for adc1
config->Instance->CR2|=1; //ADC_ON
	//change the prescaler here
ADC1_COMMON->CCR|=(0b01<<16);//prescaler /4
config->Instance->CR1&=~(0b11<<24);	
switch(config->resolution){
	case 6:
  config->Instance->CR1|=(0b11<<24);
  break;
	case 8:
	config->Instance->CR1|=(0b10<<24);
	break;
	case 10:
	config->Instance->CR1|=(0b01<<24);
	break;
	case 12:
	break;

  }

if (config->ContinuousMode==1)
	config->Instance->CR2|=(1<<1);//choose continuous mode
  else config->Instance->CR2&=~(1<<1);//choose single conversion mode

if (config->ScanMode==1)
	config->Instance->CR1|=(1<<8);
else config->Instance->CR1&=~(1<<8);

config->Instance->SQR1&=~(0b1111<<20);//we r doing the conversion of only one channel
config->Instance->SQR3 &= ~(0x1F);   // Clear previous channel selection
config->Instance->SQR3 |= (config->Channel & 0x1F); // Set new channel

config->Instance->CR2 = (config->Instance->CR2 & ~(1 << 11)) | (config->DataAlign << 11);//picking alignment

//we r gonna leave the sampling time as it is
return 0;
}


uint16_t ADC_Read(void){

ADC1->CR2|=(1<<30);//start conversion
 while (!(ADC1->SR & ADC_SR_EOC)) {
        // Wait for EOC flag
    }
	return((uint16_t)(ADC1->DR));
}

int8_t ADC_ReadMulti(uint16_t * buffer, uint8_t length){
	ADC1->CR2|=(1<<10);//set the EOCS to 1
	ADC1->CR2|=(1<<30);//start conversion
	uint8_t i=0;
	while(i<length)
	{  while (!(ADC1->SR & ADC_SR_EOC)) {
        // Wait for EOC flag
    }
		
		*(buffer+i)=(uint16_t)(ADC1->DR);
		i++;
	}
return(1);}
void ADC_IRQHandler(void) {
    if (ADC1->SR & (1 << 1)) { // Check if EOC flag is set
			ADC1->SR &= ~(1 << 1); // clear flag
        uint16_t adc_value = ADC1->DR; // Read ADC data (clears the flag)
        // Process adc_value
    }
}

void ADC_Start_DMA(uint16_t *buffer, uint8_t length,uint8_t request ){
RCC->AHB1ENR|=(1<<22);//enable clock for dma2
DMA2_Stream0->CR |= (1 << 10);  // Set Circular mode (if needed)

DMA2_Stream0->NDTR = length; // Number of data transfers
DMA2_Stream0->PAR = (uint32_t)&ADC1->DR; // Peripheral address (ADC data register)
DMA2_Stream0->M0AR = (uint32_t)buffer; // Memory address (destination buffer)

// Configure the direction: Peripheral-to-Memory (00 in bits 7:6)
DMA2_Stream0->CR &= ~(0b11 << 6);  // Clear bits 7:6 to set Periph-to-Mem (00)

// Enable the DMA stream
DMA2_Stream0->CR |= (1 << 0);
ADC1->CR2|=(1<<8);//enable DMA
	
if (request==0) //no continuous request
ADC1->CR2&=~(1<<9);
else if (request==1)//continuous request
	ADC1->CR2|=(1<<9);
uint8_t i;
for(i=0;i<length,i++;){
*(buffer+i)=ADC_Read();
}

}

int8_t ADC_EnableInterrupt(void){
	ADC1->CR1|=(1<<5);
	NVIC_EnableIRQ(ADC_IRQn);
	return (1);
}
