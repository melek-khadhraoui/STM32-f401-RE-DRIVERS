
#ifndef ADC_DRIVER_H
#define ADC_DRIVER_H

#include "stm32f401xe.h"  // Adjust for your STM32 series

// ADC Configuration Structure
typedef struct {
    ADC_TypeDef *Instance;   // ADC1, ADC2, or ADC3
    uint8_t Channel;         // ADC Channel number (0-15)
    uint8_t ContinuousMode;  // 1 = Continuous, 0 = Single conversion
    uint8_t ScanMode;        // 1 = Scan multiple channels, 0 = Single channel
    uint8_t DataAlign;       // 0 = Right, 1 = Left
    uint8_t SamplingTime;    // ADC Sampling time (in ADC clock cycles)
	 uint8_t resolution;
} ADC_Config_t;

// Function Prototypes

int8_t ADC_Init(ADC_Config_t *config);



/**
 * @brief  Start ADC conversion (single-channel)
 * @param  None
 * @return Converted 12-bit ADC value
 */
uint16_t ADC_Read(void);

/**
 * @brief  Start ADC conversion in scan mode (multi-channel)
 * @param  buffer: Pointer to store converted values
 * @param  length: Number of channels to read
 * @return 0 on success, -1 on error
 */
int8_t ADC_ReadMulti(uint16_t *buffer, uint8_t length);

/**
 * @brief  Configure and start ADC using DMA
 * @param  buffer: Pointer to store ADC values
 * @param  length: Number of conversions
 * @return 0 on success, -1 on error
 */
void ADC_Start_DMA(uint16_t *buffer, uint8_t length,uint8_t request);

/**
 * @brief  Enable ADC interrupt and configure NVIC
 * @param  None
 * @return 0 on success, -1 on error
 */
int8_t ADC_EnableInterrupt(void);

/**
 * @brief  ADC Interrupt Handler (to be called in ISR)
 */
void ADC_IRQHandler(void);

#endif 
