/*This is an stm32f401xe driver written by Malek Khadhraoui 
									on 11/03/2025                            */

#include "spi.h"

void SPI_Init(SPI_TypeDef *spi, SPI_Mode_t mode, SPI_Direction_t direction,SPI_DataSize_t DataSize,  
              SPI_BaudRatePrescaler_t clock_speed, SPI_ClockPolarity_t polarity,SPI_FirstBit_t FirstBit,
              SPI_ClockPhase_t phase,SPI_NSS_t SlaveSelect, SPI_INTERRUPT_t interrupt)
{
	if(spi==SPI1)
	RCC_SPI1_ENABLE(); //enabling RCC for SPI
	else if(spi==SPI2)
	RCC_SPI2_ENABLE();
	else if (spi==SPI3)
	RCC_SPI3_ENABLE();
	else
	RCC_SPI4_ENABLE();
	
  spi->CR1|=(mode<<2);//setting mode slave or master
	
	if(direction ==SPI_DIRECTION_2LINES || direction==SPI_DIRECTION_2LINES_RXONLY)// setting direction
	spi->CR1|=(0<<15);
	else spi->CR1|=(1<<15);//one line half duplex
	
  if(direction==SPI_DIRECTION_2LINES_RXONLY) //receive only
	spi->CR1|=(1<<10);
	
	if (DataSize==SPI_DATASIZE_8BIT)        //fixing data size
	spi->CR1&=~(0<<11);
	else if(DataSize==SPI_DATASIZE_16BIT)
	spi->CR1|=(1<<11);
	
	spi->CR1&=~(0b111<<3);//clock prescaler here
  if (clock_speed==SPI_BAUDRATEPRESCALER_2)
	spi->CR1&=~(0b111<<3);
	else if (clock_speed==SPI_BAUDRATEPRESCALER_4)
  spi->CR1|=(0x01<<3);
	else if (clock_speed==SPI_BAUDRATEPRESCALER_8)
  spi->CR1|=(0x02<<3);
	else if (clock_speed==SPI_BAUDRATEPRESCALER_16)
  spi->CR1|=(0x03<<3);
	else if (clock_speed==SPI_BAUDRATEPRESCALER_32)
  spi->CR1|=(0x04<<3);
	else if (clock_speed==SPI_BAUDRATEPRESCALER_64)
  spi->CR1|=(0x05<<3);
	else if (clock_speed==SPI_BAUDRATEPRESCALER_128)
  spi->CR1|=(0x06<<3);
	else if (clock_speed==SPI_BAUDRATEPRESCALER_256)
  spi->CR1|=(0x07<<3);

  if(polarity== SPI_CPOL_LOW) // clock polarity here
		spi->CR1&=~(1<<1);
	else if (polarity== SPI_CPOL_HIGH)
		spi->CR1|=(1<<1);
	
	spi->CR1|=(FirstBit<<7);//choose first bit 
	
	spi->CR1|=phase; //choose clock_phase(first edge or second)
	
	if(SlaveSelect== SPI_NSS_HARDWARE) // slave select
		spi->CR2|=(1<<2);
	else 
		spi->CR2&=~(1<<2);
	
	
	if(interrupt==TX_BUFFER_EMPTY_INTERRUPT) // interrupt enabling
		spi->CR2|=(1<<7);
	else if (interrupt==RX_BUFFER_NOT_EMPTY_INTERRUPT)
		spi->CR2|=(1<<6);	

}


// Function to transmit data via SPI using DMA
void SPI_Transmit_DMA(SPI_TypeDef *spi, uint8_t *pData, uint16_t size) {
    DMA_Stream_TypeDef *dmaStream;
    uint32_t dmaFlag;

    // Enable DMA for SPI TX 
    spi->CR2 |= (1 << 1); 

    // Select the correct DMA stream and flag based on the SPI instance
    if (spi == SPI1) {
        dmaStream = DMA2_Stream3;
        dmaFlag = (1 << 27); 
    } else if (spi == SPI2) {
        dmaStream = DMA1_Stream5;
        dmaFlag = (1 << 21);  
    } else if (spi == SPI3) {
        dmaStream = DMA1_Stream7;
        dmaFlag = (1 << 23); 
    } else {
        return; 
    }

    // Disable DMA stream before configuration
    dmaStream->CR &= ~(1 << 0);  

    dmaStream->PAR = (uint32_t)&(spi->DR);  // SPI data register
    dmaStream->M0AR = (uint32_t)pData;      // Memory address
    dmaStream->NDTR = size;                 // Number of data items

 
    dmaStream->CR &= ~(3 << 6);  // Clear DIR bits
    dmaStream->CR |= (1 << 6);   // Set DIR to 01 (Memory-to-Peripheral)


    // Enable the DMA stream
    dmaStream->CR |= (1 << 0);  // Set EN bit

    // Enable SPI (set SPE bit)
    spi->CR1 |= (1 << 6);  // SPI_CR1_SPE

    // Wait for DMA transfer to complete
    while (!(DMA1->HISR & dmaFlag)) {}

    // Clear the transfer complete flag
    DMA1->HIFCR |= dmaFlag;

    // Disable DMA stream after transfer
    dmaStream->CR &= ~(1 << 0);  // Clear EN bit (disable DMA)
}

// Function to receive data via SPI using DMA
void SPI_Receive_DMA(SPI_TypeDef *spi, uint8_t *pData, uint16_t size) {
    DMA_Stream_TypeDef *dmaStream;

    // Enable DMA for SPI RX (set RXDMAEN bit)
    spi->CR2 |= (1 << 0);  

    // Select the correct DMA stream based on the SPI instance
    if (spi == SPI1) {
        dmaStream = DMA2_Stream2;
    } else if (spi == SPI2) {
        dmaStream = DMA1_Stream3;
    } else if (spi == SPI3) {
        dmaStream = DMA1_Stream0;
    } else {
        return; 
    }

    // Disable DMA stream before configuration
    dmaStream->CR &= ~(1 << 0);  

    // Configure memory and peripheral addresses
    dmaStream->PAR = (uint32_t)&(spi->DR);  // SPI data register
    dmaStream->M0AR = (uint32_t)pData;      // Memory address
    dmaStream->NDTR = size;                 // Number of data items

    // Set DMA direction: peripheral to memory (DIR[1:0] = 00)
    dmaStream->CR &= ~(3 << 6); 

    // Enable the DMA stream
    dmaStream->CR |= (1 << 0);  

    // Enable SPI (set SPE bit)
    spi->CR1 |= (1 << 6);  
}

// Function to perform both SPI transmit and receive using DMA
void SPI_TransmitReceive_DMA(SPI_TypeDef *spi, uint8_t *pTxData, uint8_t *pRxData, uint16_t size) {
    SPI_Transmit_DMA(spi, pTxData, size); // Transmit data
    SPI_Receive_DMA(spi, pRxData, size);  // Receive data
}


// Transmit data using interrupts
void SPI_Transmit_IT(SPI_TypeDef *spi, uint8_t *pData, uint16_t size){
static uint16_t i=0;
spi->DR=*(pData+i);
if(i>=size-1)
spi->CR2&=~(1<<7);//disable the transmission interrupt
}

// Receive data using interrupts
void SPI_Receive_IT(SPI_TypeDef *spi, uint8_t *pData, uint16_t size){
static uint16_t i=0;
*(pData+i)=spi->DR;
spi->CR2&=~(1<<6);	
}

// Disable the SPI peripheral
void SPI_Disable(SPI_TypeDef *spi){
while(((spi->SR)&1)!= 0 || ((spi->SR>>1)&1 != 0 || ((spi->SR>>7)&1)))!=0;
spi->CR1&=~(1<<6);//finally disable spi
}
// Check for SPI errors
uint8_t SPI_CheckError(SPI_TypeDef *spi) {
    uint8_t errorCode = 0;

    // Check for Overrun Error 
    if ((spi->SR & (1 << 6))>>6 != 0) {  
        errorCode |= 0x01;  // Set bit 0 to indicate OVR error
        (void)spi->DR;       // Dummy reading DR to clear OVR flag
        (void)spi->SR;       // Dummy reading SR to clear OVR flag
    }

    // Check for Mode Fault (MODF)
    if ((spi->SR & (1 << 5))>>5 != 0) {  // SPI_SR_MODF (Bit 5)
        errorCode |= 0x02;  // Set bit 1 to indicate MODF error
        spi->CR1 &= ~(1 << 6); // Clear SPE to disable SPI and clear MODF flag
    }

    // Check for CRC Error (CRCERR)
    if ((spi->SR & (1 << 4))>>4 != 0) {  // SPI_SR_CRCERR (Bit 4)
        errorCode |= 0x04;  // Set bit 2 to indicate CRC error
        spi->SR &= ~(1 << 4); // Clear CRC error flag by writing 0
    }

    return errorCode; 
}

