#ifndef SPI_H
#define SPI_H

#include "stm32f401xe.h"
#define RCC_SPI1_ENABLE() (RCC->APB2ENR|=(1<<12))
#define RCC_SPI2_ENABLE() (RCC->APB1ENR|=(1<<14))
#define RCC_SPI3_ENABLE() (RCC->APB1ENR|=(1<<15))
#define RCC_SPI4_ENABLE() (RCC->APB2ENR|=(1<<13))
// Enum Definitions
typedef enum {
    SPI_MODE_SLAVE  = 0x00,
    SPI_MODE_MASTER = 0x01
} SPI_Mode_t;

typedef enum {
    SPI_DIRECTION_2LINES        = 0x00,  // Full-Duplex
    SPI_DIRECTION_2LINES_RXONLY = 0x01,  // Simplex RX
    SPI_DIRECTION_1LINE         = 0x02   // Half-Duplex
} SPI_Direction_t;

typedef enum {
    SPI_DATASIZE_8BIT  = 0x00,
    SPI_DATASIZE_16BIT = 0x01
} SPI_DataSize_t;

typedef enum {
    SPI_CPOL_LOW  = 0x00,
    SPI_CPOL_HIGH = 0x01
} SPI_ClockPolarity_t;

typedef enum {
    SPI_CPHA_1EDGE = 0x00,
    SPI_CPHA_2EDGE = 0x01
} SPI_ClockPhase_t;

typedef enum {
    SPI_NSS_HARDWARE = 0x00,
    SPI_NSS_SOFTWARE = 0x01
} SPI_NSS_t;

typedef enum{
    TX_BUFFER_EMPTY_INTERRUPT = 0x00,
    RX_BUFFER_NOT_EMPTY_INTERRUPT =0x01
}SPI_INTERRUPT_t;

typedef enum {
    SPI_BAUDRATEPRESCALER_2   = 0x00,
    SPI_BAUDRATEPRESCALER_4   = 0x01,
    SPI_BAUDRATEPRESCALER_8   = 0x02,
    SPI_BAUDRATEPRESCALER_16  = 0x03,
    SPI_BAUDRATEPRESCALER_32  = 0x04,
    SPI_BAUDRATEPRESCALER_64  = 0x05,
    SPI_BAUDRATEPRESCALER_128 = 0x06,
    SPI_BAUDRATEPRESCALER_256 = 0x07
} SPI_BaudRatePrescaler_t;

typedef enum {
    SPI_FIRSTBIT_MSB = 0x00,
    SPI_FIRSTBIT_LSB = 0x01
} SPI_FirstBit_t;

// Function Prototypes

// SPI Initialization
void SPI_Init(SPI_TypeDef *spi, SPI_Mode_t mode, SPI_Direction_t direction,SPI_DataSize_t DataSize,  
              SPI_BaudRatePrescaler_t clock_speed, SPI_ClockPolarity_t polarity,SPI_FirstBit_t FirstBit,
              SPI_ClockPhase_t phase,SPI_NSS_t SlaveSelect, SPI_INTERRUPT_t interrupt);

// Enable the SPI peripheral
void SPI_Enable(SPI_TypeDef *spi);

// Transmit data using DMA
void SPI_Transmit_DMA(SPI_TypeDef *spi, uint8_t *pData, uint16_t size);

// Receive data using DMA
void SPI_Receive_DMA(SPI_TypeDef *spi, uint8_t *pData, uint16_t size);

// Full-Duplex Transmit/Receive using DMA
void SPI_TransmitReceive_DMA(SPI_TypeDef *spi, uint8_t *pTxData, 
                             uint8_t *pRxData, uint16_t size);

// Transmit data using interrupts
void SPI_Transmit_IT(SPI_TypeDef *spi, uint8_t *pData, uint16_t size);

// Receive data using interrupts
void SPI_Receive_IT(SPI_TypeDef *spi, uint8_t *pData, uint16_t size);

// SPI Interrupt Handler
//void SPI_IRQ_Handler(SPI_TypeDef *spi);


// Disable the SPI peripheral
void SPI_Disable(SPI_TypeDef *spi);


// Check for SPI errors
uint8_t SPI_CheckError(SPI_TypeDef *spi);

// Deinitialize the SPI peripheral
void SPI_DeInit(SPI_TypeDef *spi);

#endif // SPI_H
