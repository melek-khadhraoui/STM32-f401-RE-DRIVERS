#include "stm32f401xe.h"
#ifndef EXTI_H
#define EXTI_H
typedef enum {
	rising_edge=0,
	falling_edge,
	both}Trigger;
#define ClearFlag(pin) (EXTI->PR=(1<<pin))
void EXTI_Init(GPIO_TypeDef* port , uint8_t pin);

void EXTI_Enable(uint8_t pin, Trigger T);

void EXTI_Disable(uint8_t pin);


void EXTI_Callback(uint8_t pin);
	

#endif // EXTI_DRIVER_H