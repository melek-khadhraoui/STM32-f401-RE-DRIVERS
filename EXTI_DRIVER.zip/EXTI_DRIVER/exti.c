/* This is an exti driver for stm32f401RE*/
/*Written by malek khadhraoui on 02/02/2025*/

#include "exti.h"
void EXTI_Init(GPIO_TypeDef* port ,uint8_t pin){
 uint8_t exti_index = pin / 4; // determines which EXCTICR[] to use
 uint8_t position = (pin % 4) * 4; // index of shifting
	SYSCFG->EXTICR[exti_index]&=~(0b1111<<position);
switch ((uint32_t)port) {
    case (uint32_t)GPIOA:
        SYSCFG->EXTICR[exti_index] |= (0b0000 << position);
        break;
    
    case (uint32_t)GPIOB:
        SYSCFG->EXTICR[exti_index] |= (0b0001 << position);
        break;
    
    case (uint32_t)GPIOC:
        SYSCFG->EXTICR[exti_index] |= (0b0010 << position);
        break;
    
    case (uint32_t)GPIOD:
        SYSCFG->EXTICR[exti_index] |= (0b0011 << position);
        break;
    
    case (uint32_t)GPIOE:
        SYSCFG->EXTICR[exti_index] |= (0b0100 << position);
        break;
    
    case (uint32_t)GPIOH:
        SYSCFG->EXTICR[exti_index] |= (0b0111 << position);
        break;
    
    default:
        // error handling
        break;
}

}

void EXTI_Enable(uint8_t pin, Trigger T){
	EXTI->IMR|=(1<<pin);
	if (T==rising_edge)
		EXTI->RTSR|=(1<<pin);
	else if (T==falling_edge)
		EXTI->FTSR|=(1<<pin);
	else if (T==both)
	{EXTI->RTSR|=(1<<pin);
	 EXTI->FTSR|=(1<<pin);
	}
}
void EXTI_Disable(uint8_t pin){
	EXTI->IMR&=~(1<<pin);}
//here for testing as i chose as a callback function setting the PA5 led high
void EXTI_Callback(uint8_t pin){
ClearFlag(pin);
	GPIOA->MODER&=(0b11<<(2*pin));
	GPIOA->MODER|=(1<<(2*pin));
	GPIOA->ODR|=(1<<5);
}
void EXTI15_10_IRQHandler(void){
	if(((EXTI->PR)&(1<<13))>>13)//here im working with the push button PC13 as my exti pin for test
	{ClearFlag(13);
	 EXTI_Callback(13);}}