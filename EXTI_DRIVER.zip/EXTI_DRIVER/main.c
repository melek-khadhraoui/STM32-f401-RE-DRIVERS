#include "exti.h"
int main (){
	Trigger T=0;
RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN; // Enable clock for GPIOC
GPIOA->MODER |=(0x1<< (2 * 5)); // Configure pin 13 as input


	EXTI_Init(GPIOC,13);
	EXTI_Enable(13,T);
while(1){
	if((GPIOC->IDR&(1<<13))>>13)
		GPIOA->ODR|=(1<<5);
}
	return 0;
}