#include "stm32f4xx.h"
#include "gpio.h"
/* Here we have some code to test our functions using the built in led(A5) and the push button(C13)*/

int main(){
	GPIO_init(GPIOA,5,OUTPUT);
	GPIO_init(GPIOC,13,INPUT);
	long int i;
	while(1){
	TOGGLE_Pin(GPIOA,5);
    for(i=0;i<500000;i++); //this provokes a delay*/



	/*	if (READ_Pin(GPIOC,13)==0)
			WRITE_Pin(GPIOA,5,1);
		else 
			WRITE_Pin(GPIOA,5,0);*/

	}
return 0 ;}