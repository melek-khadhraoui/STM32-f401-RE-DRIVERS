/* GPIO driver for STM32 NUCLEO F401RE */
/* Created by Malek Khadhraoui on 26/01/2025*/
#include "gpio.h"

void Rcc_gpioa_clock_enable(){
RCC->AHB1ENR|=(1<<0);
}	
void Rcc_gpiob_clock_enable(){
	RCC->AHB1ENR|=(1<<1);
}
void Rcc_gpioc_clock_enable(){
	RCC->AHB1ENR|=(1<<2);
}
void Rcc_gpiod_clock_enable(){
RCC->AHB1ENR|=(1<<3);
}
void Rcc_gpioe_clock_enable(){
RCC->AHB1ENR|=(1<<4);
}
void Rcc_gpioh_clock_enable(){
RCC->AHB1ENR|=(1<<7);
}

void GPIO_init(GPIO_TypeDef* GPIOX, uint32_t PIN, GPIO_ModeTypeDef MODE, GPIO_OTypeTypeDef OTYPE, GPIO_PuPdTypeDef PUPD, GPIO_SpeedTypeDef SPEED) {
    // Enable clock and set the mode for the specific GPIO port and pin
    uint32_t gpio = (uint32_t)GPIOX;
    switch (gpio) {
        case ((uint32_t)GPIOA):
            Rcc_gpioa_clock_enable();  // Enable clock for GPIOA
            GPIOA->MODER |= (MODE << (2 * PIN));  // Set mode for pin
            GPIOA->OTYPER |= (OTYPE << PIN);  // Set output type (Push-Pull / Open-Drain)
            GPIOA->PUPDR |= (PUPD << (2 * PIN));  // Set pull-up/pull-down
            GPIOA->OSPEEDR |= (SPEED << (2 * PIN));  // Set speed
            break;  // Exit the switch after handling GPIOA

        case ((uint32_t)GPIOB):
            Rcc_gpiob_clock_enable();  // Enable clock for GPIOB
            GPIOB->MODER |= (MODE << (2 * PIN));  // Set mode for pin
            GPIOB->OTYPER |= (OTYPE << PIN);  // Set output type (Push-Pull / Open-Drain)
            GPIOB->PUPDR |= (PUPD << (2 * PIN));  // Set pull-up/pull-down
            GPIOB->OSPEEDR |= (SPEED << (2 * PIN));  // Set speed
            break;  // Exit the switch after handling GPIOB

        case ((uint32_t)GPIOC):
            Rcc_gpioc_clock_enable();  // Enable clock for GPIOC
            GPIOC->MODER |= (MODE << (2 * PIN));  // Set mode for pin
            GPIOC->OTYPER |= (OTYPE << PIN);  // Set output type (Push-Pull / Open-Drain)
            GPIOC->PUPDR |= (PUPD << (2 * PIN));  // Set pull-up/pull-down
            GPIOC->OSPEEDR |= (SPEED << (2 * PIN));  // Set speed
            break;  // Exit the switch after handling GPIOC

        case ((uint32_t)GPIOD):
            Rcc_gpiod_clock_enable();  // Enable clock for GPIOD
            GPIOD->MODER |= (MODE << (2 * PIN));  // Set mode for pin
            GPIOD->OTYPER |= (OTYPE << PIN);  // Set output type (Push-Pull / Open-Drain)
            GPIOD->PUPDR |= (PUPD << (2 * PIN));  // Set pull-up/pull-down
            GPIOD->OSPEEDR |= (SPEED << (2 * PIN));  // Set speed
            break;  // Exit the switch after handling GPIOD

        case ((uint32_t)GPIOE):
            Rcc_gpioe_clock_enable();  // Enable clock for GPIOE
            GPIOE->MODER |= (MODE << (2 * PIN));  // Set mode for pin
            GPIOE->OTYPER |= (OTYPE << PIN);  // Set output type (Push-Pull / Open-Drain)
            GPIOE->PUPDR |= (PUPD << (2 * PIN));  // Set pull-up/pull-down
            GPIOE->OSPEEDR |= (SPEED << (2 * PIN));  // Set speed
            break;  // Exit the switch after handling GPIOE

        case ((uint32_t)GPIOH):
            Rcc_gpioh_clock_enable();  // Enable clock for GPIOH
            GPIOH->MODER |= (MODE << (2 * PIN));  // Set mode for pin
            GPIOH->OTYPER |= (OTYPE << PIN);  // Set output type (Push-Pull / Open-Drain)
            GPIOH->PUPDR |= (PUPD << (2 * PIN));  // Set pull-up/pull-down
            GPIOH->OSPEEDR |= (SPEED << (2 * PIN));  // Set speed
            break;  // Exit the switch after handling GPIOH

        default:
            // Optionally handle invalid GPIO ports or unsupported cases
            break;
    }
}


void GPIO_Deinit(GPIO_TypeDef* GPIOX ){
	uint32_t gpio = (uint32_t)GPIOX;
	 switch (gpio) {
        case ((uint32_t)GPIOA):
					RCC->AHB1RSTR|=(1<<0);
            break;  // Exit the switch after handling GPIOA

        case ((uint32_t)GPIOB):
          RCC->AHB1RSTR|=(1<<1);
            break;  // Exit the switch after handling GPIOB

        case ((uint32_t)GPIOC):
          RCC->AHB1RSTR|=(1<<2);
            break;  // Exit the switch after handling GPIOC

        case ((uint32_t)GPIOD):
          RCC->AHB1RSTR|=(1<<3); 
            break;  // Exit the switch after handling GPIOD

        case ((uint32_t)GPIOE):
					RCC->AHB1RSTR|=(1<<4); 
            break;  // Exit the switch after handling GPIOE
				
        case ((uint32_t)GPIOH):
					RCC->AHB1RSTR|=(1<<7); 
            break;  // Exit the switch after handling GPIOE				

        default:
            // Optionally handle invalid GPIO ports or unsupported cases
            break;
    }
	  GPIOX->MODER = 0x00000000; // Set all pins to input mode (reset state)
    GPIOX->OTYPER = 0x00000000; // Set all pins to push-pull
    GPIOX->PUPDR = 0x00000000;  // No pull-up/pull-down
    GPIOX->OSPEEDR = 0x00000000;
}
void WRITE_Pin(GPIO_TypeDef* GPIOX , uint32_t PIN , PIN_State S){
if (S==GPIO_PIN_SET)
	GPIOX->ODR|=(1<<PIN);
else if (S==GPIO_PIN_RESET)
	GPIOX->ODR&=(~(1<<PIN));
}
PIN_State READ_Pin(GPIO_TypeDef* GPIOX , uint32_t PIN ){
	return ((GPIOX->IDR&(1<<PIN))>>PIN);

}
void TOGGLE_Pin(GPIO_TypeDef* GPIOX, uint32_t PIN){
	GPIOX->ODR^=(1<<PIN);}