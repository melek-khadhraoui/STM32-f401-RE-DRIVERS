
#ifndef HAL_GPIO_H
#define HAL_GPIO_H

#include "stm32f401xe.h"

#define GPIO_PIN_0 0
#define GPIO_PIN_1 1
#define GPIO_PIN_2 2
#define GPIO_PIN_3 3
#define GPIO_PIN_4 4
#define GPIO_PIN_5 5
#define GPIO_PIN_6 6
#define GPIO_PIN_7 7
#define GPIO_PIN_8 8
#define GPIO_PIN_9 9
#define GPIO_PIN_10 10
#define GPIO_PIN_11 11
#define GPIO_PIN_12 12
#define GPIO_PIN_13 13
#define GPIO_PIN_14 14
#define GPIO_PIN_15 15
typedef enum {
    INPUT = 0x00,
    OUTPUT = 0x01,
    AF = 0x02,
    ANALOG = 0x03
} GPIO_ModeTypeDef;

typedef enum {
    GPIO_OTYPE_PP = 0x0, // Push-pull output
    GPIO_OTYPE_OD = 0x1  // Open-drain output
} GPIO_OType_TypeDef;

typedef enum {
    GPIO_PUPD_NO_PULL = 0x0,    // No pull-up/pull-down
    GPIO_PUPD_PULL_UP = 0x1,    // Pull-up
    GPIO_PUPD_PULL_DOWN = 0x2   // Pull-down
} GPIO_PuPd_TypeDef;


typedef enum {
    GPIO_OSPEED_LOW = 0x0,     // Low speed
    GPIO_OSPEED_MEDIUM = 0x1,  // Medium speed
    GPIO_OSPEED_FAST = 0x2,    // Fast speed
    GPIO_OSPEED_HIGH = 0x3     // High speed
} GPIO_Speed_TypeDef;

typedef enum {
	
GPIO_PIN_RESET=0,
GPIO_PIN_SET 
}PIN_State;

                            /*          functions prototypes         */


//Functions to enable clock for gpio_port//
void Rcc_gpioa_clock_enable();
void Rcc_gpiob_clock_enable();
void Rcc_gpioc_clock_enable();
void Rcc_gpiod_clock_enable();
void Rcc_gpioe_clock_enable();
void Rcc_gpioh_clock_enable();


//GPIO CONFIG//
void GPIO_init(GPIO_TypeDef* GPIOX , uint32_t PIN ,GPIO_ModeTypeDef MODE);
void GPIO_Deinit(GPIO_TypeDef* GPIOX );
//GPIO_READ_AND_WRITE//
void WRITE_Pin(GPIO_TypeDef* GPIOX , uint32_t PIN , PIN_State S);
PIN_State READ_Pin(GPIO_TypeDef* GPIOX , uint32_t PIN );
void TOGGLE_Pin(GPIO_TypeDef* GPIOX, uint32_t PIN);
#endif

