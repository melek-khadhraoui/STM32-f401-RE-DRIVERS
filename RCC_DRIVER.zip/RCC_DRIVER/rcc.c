#include "rcc.h"

void RCC_HSE_Enable()
{RCC->CR|=(1<<16);
 while(((RCC->CR&(1<<17))>>17)!=1){;}}
void RCC_HSE_Disable()
{
RCC->CR&=~(1<<16);}

void RCC_HSI_Enable(){
while(((RCC->CR&(1<<1))>>1)!=1){;}
}

void RCC_HSI_Disable()
	{RCC->CR&=~(0x1);
}
void RCC_PLL_Config(CLOCK_TYPE pll_source, uint32_t pll_multiplier){
	if (pll_source==HSE)
	{ RCC_HSE_Enable();
		RCC->PLLCFGR|=(1<<22);}
switch(pll_multiplier){
	case 4:
		RCC->PLLCFGR|=(0x01<<16);
	 break;
	case 6:
		RCC->PLLCFGR|=(0x02<<16);
	 break;
	case 8:
		RCC->PLLCFGR|=(0<03<<16);
		
}}

void RCC_PLL_Enable(){
RCC->CR|=(1<<24);
}
void RCC_PLL_Disable(void){
	RCC->CR&=~(1<<24);
}
void RCC_init(CLOCK_TYPE T){
if(T==HSE)
	RCC_HSE_Enable();
	else if (T==HSI)
		RCC_HSI_Enable();
	
}

void RCC_Set_Sys_Clock_Source(CLOCK_TYPE T)
{if(T==HSE)
	RCC->CFGR|=(0x01);
else if (T==PLL)
	RCC->CFGR|=(0x02);
}
void Rcc_gpioa_clock_enable(){
RCC->AHB1ENR|=(1<<0);
}	
void Rcc_gpiob_clock_enable(){
	RCC->AHB1ENR|=(1<<1);
}
void Rcc_gpioc_clock_enable(){
	RCC->AHB1ENR|=(1<<2);
}
void Rcc_gpiod_clock_enable(){
RCC->AHB1ENR|=(1<<3);
}
void Rcc_gpioe_clock_enable(){
RCC->AHB1ENR|=(1<<4);
}
void Rcc_gpioh_clock_enable(){
RCC->AHB1ENR|=(1<<7);
}
void RCC_USART_Clock_Enable(){
	RCC->APB2ENR|=(1<<4);}

void RCC_USART_ClockDisable()
{RCC->APB2ENR&=~(1<<4);}


uint16_t RCC_Get_Sys_Clock_Source()
{uint16_t clock_source = (RCC->CFGR & (0x03<<2)) >> 2;
    return clock_source;}
