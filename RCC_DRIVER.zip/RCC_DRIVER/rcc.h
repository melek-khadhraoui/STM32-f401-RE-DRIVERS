#ifndef RCC_H
#define RCC_H
#include "stm32f4xx.h"
typedef enum {
 HSI=0,
 HSE ,
 PLL}CLOCK_TYPE;
void RCC_init(CLOCK_TYPE);
void RCC_HSE_Enable(void);
void RCC_HSE_Disable(void);
void RCC_HSI_Enable(void);
void RCC_HSI_Disable(void);
void RCC_PLL_Config(CLOCK_TYPE pll_source, uint32_t pll_multiplier);
void RCC_PLL_Enable(void);
void RCC_PLL_Disable(void);
 void RCC_Set_Sys_Clock_Source(CLOCK_TYPE);
void Rcc_gpioa_clock_enable(void);
 void Rcc_gpiob_clock_enable(void);
 void Rcc_gpioc_clock_enable(void);
 void Rcc_gpiod_clock_enable(void);
 void Rcc_gpioe_clock_enable(void);
 void Rcc_gpioh_clock_enable(void);
void RCC_USART_Clock_Enable();
uint16_t RCC_Get_Sys_Clock_Source(void);
#endif
 