#include "rcc.h"
int main(){
	CLOCK_TYPE T=HSI;
	RCC_init(T);
	RCC_Set_Sys_Clock_Source(T);
	Rcc_gpioa_clock_enable();
	GPIOA->MODER |= (0x01 << (2 * 5));
	while(1){
	uint16_t x = RCC_Get_Sys_Clock_Source();
	if(x==0){
	GPIOA->ODR|=(1<<5);}
	else {
   GPIOA->ODR &= ~(1 << 5);  }
}
	return 0;
}