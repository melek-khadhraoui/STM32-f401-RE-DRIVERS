#ifndef UART_H
#define UART_H
#include "stm32f401xe.h"
#define PCLK 16000000 //Default 16MHZ frequency
#define RCC_USART1_ENABLE() (RCC->APB2ENR|=(1<<4))
#define RCC_USART2_ENABLE() (RCC->APB1ENR|=(1<<17))
#define RCC_USART6_ENABLE() (RCC->APB2ENR|=(1<<5))
#define GET_BIT(REG,BIT)    ((REG&(1<<BIT))>>BIT)
typedef enum{
Even_parity,
Odd_parity
}Parity_type;
typedef enum{
STOP_BIT_1,
STOP_BIT_05,
STOP_BIT_2,
STOP_BIT_15,
}Stop_Bits;
typedef enum{
WORD_8_BIT,
WORD_9_BIT
}word_length;

volatile uint8_t *txBuffer;
volatile uint16_t txLength;
volatile uint16_t txIndex = 0;
volatile uint8_t *rxBuffer;
volatile uint16_t rxLength;
volatile uint16_t rxIndex = 0;

void UART_Init(USART_TypeDef* USART,uint32_t baudrate, uint8_t parity, Parity_type P, Stop_Bits S, word_length w,uint8_t Over_Sampling);


void UART_Transmit(USART_TypeDef* USART,uint8_t data);


void UART_TransmitBuffer(USART_TypeDef* USART,uint8_t *buffer, uint16_t length);


uint8_t UART_Receive(USART_TypeDef* USART);


void UART_ReceiveBuffer(USART_TypeDef* USART,uint8_t *buffer, uint16_t length);


uint8_t UART_Available(void);

void UART_Transmit_IT(USART_TypeDef* USART, uint8_t *buffer, uint16_t length);
void UART_IRQHandler(USART_TypeDef* USART);


#endif