#include "uart.h"
void UART_Init(USART_TypeDef* USART,uint32_t baudrate, uint8_t parity, Parity_type P, Stop_Bits S, word_length w,uint8_t Over_Sampling)
{
	if(USART==USART1)
	RCC_USART1_ENABLE(); //enabling RCC for SPI
	else if(USART==USART2)
	RCC_USART2_ENABLE();
	else if (USART==USART6)
	RCC_USART6_ENABLE();
uint32_t usart_div = (PCLK * 100) / (baudrate * Over_Sampling);
uint32_t mantissa = usart_div / 100;
USART->BRR&=(mantissa<<4); //choosing baudrate
	
USART->CR1|=(P<<9);  //choosing parity type even or odd
USART->CR1|=(parity<<10); //parity enabling

USART->CR2&=~(0x02<<12);
USART->CR2|=(S<<12);  //choosing the stop bits
	
USART->CR1|=(w<<12); //choosing the word length
	
USART->CR1|=(Over_Sampling<<15); //over sampling size

USART->CR1|=(1<<13); //enabling usart
}


void UART_Transmit(USART_TypeDef* USART,uint8_t data) {
while (!GET_BIT(USART->SR,7));  //wait until TX buffer becomes empty

USART->DR = data;  
	
while (!GET_BIT(USART->SR,6));  //wait until transmission is complete
}

void UART_TransmitBuffer(USART_TypeDef* USART,uint8_t *buffer, uint16_t length)
{uint8_t i;
for(i=0;i<length-1;i++){
while (!GET_BIT(USART->SR,7)); //wait until TX buffer becomes empty

USART->DR = *(buffer+i);  
	
while (!GET_BIT(USART->SR,7));   //wait until transmission is complete
}
}

uint8_t UART_Receive(USART_TypeDef* USART){
while (!GET_BIT(USART->SR,5)); //wait until RX buffer becomes full
if((GET_BIT(USART->CR1,10))&&(!GET_BIT(USART->CR1,12))) //check if parity is enabled and  if data is on 8 bits
return(USART->DR&(~(1<<7)));
else return(USART->DR);

}

void UART_ReceiveBuffer(USART_TypeDef* USART,uint8_t *buffer, uint16_t length)
{uint8_t i;
for(i=0;i<length-1;i++){
while (!GET_BIT(USART->SR,5)); //wait until RX buffer becomes full
if((GET_BIT(USART->CR1,10))&&(!GET_BIT(USART->CR1,12))) //check if parity is enabled and  if data is on 8 bits
*(buffer+i)=(USART->DR&(~(1<<7)));
*(buffer+i)=(USART->DR);
}
}

uint8_t UART_Available(void){
if(GET_BIT(USART1->SR,4))//IDLE LINE DETECTED
 return(1);
}


void UART_Transmit_IT(USART_TypeDef* USART, uint8_t *buffer, uint16_t length) {
    if (length == 0) return;
    txBuffer = buffer;
    txLength = length;
    txIndex = 0;
    USART->DR = txBuffer[txIndex++];  // Send first byte
    USART->CR1 |= (1 << 7);
}

void UART_Receive_IT(USART_TypeDef* USART, uint8_t *buffer, uint16_t length) {
    if (length == 0) return;
    rxBuffer = buffer;
    rxLength = length;
    rxIndex = 0;
    USART->CR1 |= (1 << 5);  // Enable RXNE interrupt
}

void UART_IRQHandler(USART_TypeDef* USART) {
    // Handle Transmit Interrupt for the correct USART
    if (GET_BIT(USART->SR, 7)) {  // TXE (Transmit Buffer Empty) for the given USART
        if (txIndex < txLength) {
            USART->DR = txBuffer[txIndex++];  // Send next byte
        } else {
            USART->CR1 &= ~(1 << 7);  // Disable TXE interrupt (transmission complete)
        }
    }

    // Handle Receive Interrupt for the correct USART
    if (GET_BIT(USART->SR, 5)) {  // RXNE (Received Data Ready) for the given USART
        rxBuffer[rxIndex++] = USART->DR;  // Store received byte
        if (rxIndex >= rxLength) {
            USART->CR1 &= ~(1 << 5);  // Disable RXNE interrupt when buffer is full
        }
    }
}


