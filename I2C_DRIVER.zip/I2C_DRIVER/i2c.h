#ifndef I2C_H
#define I2C_H
#include "stm32f401xe.h"
typedef enum
	{ I2C_WRITE = 0,
I2C_READ}
I2C_direction;
#define RCC_I2C1_ENABLE() (RCC->APB1ENR|=(1<<21))
#define RCC_I2C2_ENABLE() (RCC->APB1ENR|=(1<<22))
#define RCC_I2C3_ENABLE() (RCC->APB1ENR|=(1<<23))
// High-level functions
void I2C_Init(I2C_TypeDef *I2Cx, uint32_t clock_speed);
void I2C_Start(I2C_TypeDef *I2Cx);
void I2C_Stop(I2C_TypeDef *I2Cx);
void I2C_SendAddress(I2C_TypeDef *I2Cx,uint8_t address, I2C_direction direction);
void I2C_WriteData(I2C_TypeDef *I2Cx,uint8_t data);
uint8_t I2C_ReadDataAck(I2C_TypeDef *I2Cx);
uint8_t I2C_ReadDataNack(I2C_TypeDef *I2Cx);

// Utility functions (optional but good to have)
uint8_t I2C_WriteRegister(I2C_TypeDef *I2Cx,uint32_t clock_speed,uint8_t dev_addr, uint8_t reg_addr, uint8_t data);
uint8_t I2C_ReadRegister(I2C_TypeDef *I2Cx,uint32_t clock_speed,uint8_t dev_addr, uint8_t reg_addr);






#endif