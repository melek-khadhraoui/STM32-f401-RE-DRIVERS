/* I2C driver for STM32 NUCLEO F401RE 
 Created by Malek Khadhraoui on 30/04/2025
This is a minimalist driver for I2C controller mode*/
#include "i2c.h"
void I2C_Init(I2C_TypeDef *I2Cx, uint32_t clock_speed){
I2Cx->CR2|=(clock_speed);
		if(I2Cx==I2C1)
	RCC_I2C1_ENABLE(); //enabling RCC for SPI
	else if(I2Cx==I2C2)
	RCC_I2C2_ENABLE();
	else if (I2Cx==I2C3)
	RCC_I2C3_ENABLE();
}
void I2C_Start(I2C_TypeDef *I2Cx){
I2Cx->CR1|=(1<<8);
while(!(I2Cx->SR1&1)); //wait for the start condition to be generated
}
void I2C_Stop(I2C_TypeDef *I2Cx){
I2Cx->CR1|=(1<<9);
}
void I2C_SendAddress(I2C_TypeDef *I2Cx,uint8_t address, I2C_direction direction ){
I2Cx->DR=((address<<1)|direction );
while (!( (I2Cx->SR1 >>1) & 1 )); // wait until adress is transmitted
}
void I2C_WriteData(I2C_TypeDef *I2Cx,uint8_t data){
I2Cx->DR=data;
while (!( (I2Cx->SR1 >> 7) & 1 )); //wait until data is transmitted
}

uint8_t I2C_ReadDataAck(I2C_TypeDef *I2Cx){
while (!(I2Cx->SR1>>6 & 1));  
 uint8_t data = I2Cx->DR;
	I2Cx->CR1|=1<<10;
	return data;
}
uint8_t I2C_ReadDataNack(I2C_TypeDef *I2Cx){ //this is typically used when the last byte is received and we need to stop the communication
while (!(I2Cx->SR1>>6 & 1));  
 uint8_t data = I2Cx->DR;
		I2Cx->CR1&=~(1<<10);
	I2C_Stop(I2Cx);
	return data;
}
uint8_t I2C_WriteRegister(I2C_TypeDef *I2Cx,uint32_t clock_speed,uint8_t dev_addr, uint8_t reg_addr, uint8_t data){
I2C_Start(I2Cx);

    // Send device address with write mode (0 for write)
    I2C_SendAddress(I2Cx, dev_addr, I2C_WRITE);

    // Send register address
    I2C_WriteData(I2Cx, reg_addr);

    // Write the data to the register
    I2C_WriteData(I2Cx, data);

    // Stop I2C communication
    I2C_Stop(I2Cx);

    return 0; // Success
}
uint8_t I2C_ReadRegister(I2C_TypeDef *I2Cx,uint32_t clock_speed,uint8_t dev_addr, uint8_t reg_addr){
I2C_Start(I2Cx);

    // Send device address with write mode (0 for write)
    I2C_SendAddress(I2Cx, dev_addr, I2C_WRITE);

    // Send register address
    I2C_WriteData(I2Cx, reg_addr);

    // Restart I2C communication for read
    I2C_Start(I2Cx);

    // Send device address with read mode (1 for read)
    I2C_SendAddress(I2Cx, dev_addr, I2C_READ);

    // Read data with acknowledgment (ACK)
    uint8_t data = I2C_ReadDataAck(I2Cx);

    // Stop I2C communication
    I2C_Stop(I2Cx);

    return data; // Return the read data
	}
/*?? Full I2C Read Register Sequence:
START condition
You initiate communication on the I2C bus.

Send device address with WRITE (R/W = 0)
 You're telling the slave: �I want to write something to you.�

Send register address
 You're saying: �I want to read from this register.�

REPEATED START
 This keeps the bus busy and avoids releasing control.
It signals: �I'm not done yet � switching to read mode now.�

Send device address with READ (R/W = 1)
 You're saying: �Now I want to read the data from the register I just told you.�

Receive data byte
 The slave sends you the byte from the requested register.

STOP condition
Communication is over.

*/